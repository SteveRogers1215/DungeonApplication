﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DungeonLibrary
{
    public enum Race
    {
        Orc,
        Human,
        Elf,
        Dwarf,
        Goblin,
        Ent,
        Demon,
        Angel,
        Saiyan
    }
}
